// 引入各模块
import Food from './Food';
import Panel from './Panel';
import Snake from './Snake';

// 控制类
class Controller {
    // 组件
    snake: Snake;
    food: Food;
    panel: Panel;
    // 方向
    direct: string = "Right";
    // 合法取值
    valid: string[] = ["ArrowUp", "Up", "ArrowDown", "Down", "ArrowLeft", "Left", "ArrowRight", "Right"]
    // 是否结束
    isOver: boolean = false;

    constructor() {
        this.snake = new Snake();
        this.food = new Food();
        this.panel = new Panel();

        this.init();
    }

    // 绑定键盘监听事件
    init(): void {
        document.addEventListener('keydown', this.kbHandler.bind(this));
        this.run();
    }

    // 键盘回调
    kbHandler(event: KeyboardEvent) {
        // 修改存储的方向状态
        let key: string = event.key;
        let curIdx = this.valid.indexOf(key);
        if (curIdx >= 0) {
            // 禁止掉头
            if (this.snake.length > 1) {
                let prevIdx = this.valid.indexOf(this.direct);
                if (curIdx / 2 === 0 && prevIdx / 2 === 1) return;
                if (curIdx / 2 === 1 && prevIdx / 2 === 0) return;
                if (curIdx / 2 === 2 && prevIdx / 2 === 3) return;
                if (curIdx / 2 === 3 && prevIdx / 2 === 2) return;
            }

            this.direct = event.key;
        }
    }

    // 判断是否得分
    checkAte(X: number, Y: number): void {
        if (X === this.food.X && Y === this.food.Y) {
            this.food.move()
            this.panel.incScore()
            this.snake.grow()
        }
    }

    // 让 snake 向指定方向移动
    run(): void {
        // 🐍之前的坐标
        let X = this.snake.X;
        let Y = this.snake.Y;

        switch (this.direct) {
            case "ArrowUp":
            case "Up":
                Y -= 10;
                break;
            case "ArrowDown":
            case "Down":
                Y += 10;
                break;
            case "ArrowLeft":
            case "Left":
                X -= 10;
                break;
            case "ArrowRight":
            case "Right":
                X += 10;
                break;
        }

        try {
            this.snake.checkCollision(X, Y);  // 是否撞到自身
        } catch (e) {
            alert(e.message)
            this.isOver = true
        }

        // 是否得分
        this.checkAte(X, Y);

        // 应用修改
        try {

            this.snake.X = X;
            this.snake.Y = Y;
        } catch (e) {
            alert(e.message)
            this.isOver = true
        }

        // 定时器
        !this.isOver && setTimeout(this.run.bind(this), 300 - (this.panel.level - 1) * 30);
    }
}

export default Controller;