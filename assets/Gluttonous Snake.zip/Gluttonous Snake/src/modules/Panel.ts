// 积分类
class Panel {
	score: number = 0;
	scoreEle: HTMLElement;

	level: number = 1;
	levelEle: HTMLElement;

	readonly maxLevel: number; // 最大等级，默认为 10
	readonly levelGap: number; // 升级的分数间隔，默认为 10

	constructor(maxLevel: number = 10, levelGap: number = 10) {
		this.scoreEle = document.getElementById("score")!;
		this.levelEle = document.getElementById("level")!;
		this.maxLevel = maxLevel;
		this.levelGap = levelGap;
	}

	incScore() {
		this.score++;
		this.scoreEle.innerHTML = this.score + '';
		// 判断升级
		if(this.score % this.levelGap === 0) {
			this.incLevel();
		}
	}

	incLevel() {
		if (this.level < this.maxLevel) {
			this.level++;
			this.levelEle.innerHTML = this.level + '';
		}
	}
}

export default Panel;