// 贪吃蛇本体
class Snake {
    container: HTMLElement; // 外部容器
    head: HTMLElement;
    body: HTMLCollection; // 一个会实时更新的集合
    
    constructor() {
        this.container = document.getElementById('snake')!;
        // 头部元素是 #snake 下的第一个 div 元素
        this.head = document.querySelector('#snake > div') as HTMLAreaElement;
        this.body = this.container.getElementsByTagName('div');
    }
    
    // 获取身体长度
    get length(): number {
        return this.body.length
    }

    // 获取蛇头坐标
    get X(): number{
        return this.head.offsetLeft;
    }
    set X(neoX: number) {
        if (this.X === neoX) return;
        // 判断越界
        if (neoX < 0 || neoX > 290) {
            throw new Error("Hit the WALL!")
        }
        this.moveBody()
        this.head.style.left = neoX + 'px';
    }
    get Y(): number{
        return this.head.offsetTop;
    }
    set Y(neoY: number) {
        if (this.Y === neoY) return;
        // 判断越界
        if (neoY < 0 || neoY > 290) {
            throw new Error("Hit the WALL!")
        }
        this.moveBody()
        this.head.style.top  = neoY + 'px';
    }

    // 增加长度
    grow() {
        // 向 container 末尾添加一个 div 标签
        this.container.insertAdjacentHTML('beforeend', `<div></div>`);
    }

    // 身体部分的联协移动
    moveBody() {
        for (let i = this.body.length - 1; i > 0 ; i--) {
            let prevX = (this.body[i-1] as HTMLElement).offsetLeft;
            let prevY = (this.body[i-1] as HTMLElement).offsetTop;
            // 设置当前节点位置
            (this.body[i] as HTMLElement).style.left = prevX + 'px';
            (this.body[i] as HTMLElement).style.top  = prevY + 'px';
        }
    }

    // 判断头和身体是否碰撞
    checkCollision(X: number, Y: number): void {
        for (let i = 1; i < this.body.length ; i++) {
            if (X === (this.body[i] as HTMLElement).offsetLeft && Y === (this.body[i] as HTMLElement).offsetTop) {
                throw new Error("Ate Yourself!")
            }
        }
    }
}

export default Snake;