// 食物类
class Food {
	// 对应的页面元素
	element: HTMLElement;
	// 构造时自动获取页面中的指定元素
	constructor() {
		this.element = document.getElementById("food")!; // ! 提示编译器本元素一定不为空
	}
	// 获取食物元素坐标
	get X() {
		return this.element.offsetLeft;
	}
	get Y() {
		return this.element.offsetTop;
	}
	// 修改位置
	move(): void {
		// 生成随机数，范围在 [0, 290]，蛇每次移动 10px
		this.element.style.left = Math.round(Math.random()*29) * 10 + 'px';
		this.element.style.top  = Math.round(Math.random()*29) * 10 + 'px';
	}
}

export default Food;