// 引入样式表
import './index.less';

// 引入控制类
import Controller from './modules/Controller';
new Controller();